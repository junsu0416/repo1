package kr.co.mandoo.dao;

import java.util.List;


import kr.co.mandoo.dto.ProductionstatusDTO;

public interface ProductionStatusDAO {
	
	public List<ProductionstatusDTO> StatusList();

}
