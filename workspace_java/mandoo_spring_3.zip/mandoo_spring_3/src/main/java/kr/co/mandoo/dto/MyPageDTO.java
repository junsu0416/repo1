package kr.co.mandoo.dto;

public class MyPageDTO {
    private String mypageId;
    private String userId;
    private String mypageName;
    private String mypageAffiliation;
    private String mypageIntel;
    private String mypagePhone;
    private String mypagePosition;
    private String mypageMainnum;
    private String mypageAddress;
    private String mypageBirth;
    private String mypageLog;


    public String getMypageId() {
        return mypageId;
    }

    public void setMypageId(String mypageId) {
        this.mypageId = mypageId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMypageName() {
        return mypageName;
    }

    public void setMypageName(String mypageName) {
        this.mypageName = mypageName;
    }

    public String getMypageAffiliation() {
        return mypageAffiliation;
    }

    public void setMypageAffiliation(String mypageAffiliation) {
        this.mypageAffiliation = mypageAffiliation;
    }

    public String getMypageIntel() {
        return mypageIntel;
    }

    public void setMypageIntel(String mypageIntel) {
        this.mypageIntel = mypageIntel;
    }

    public String getMypagePhone() {
        return mypagePhone;
    }

    public void setMypagePhone(String mypagePhone) {
        this.mypagePhone = mypagePhone;
    }

    public String getMypagePosition() {
        return mypagePosition;
    }

    public void setMypagePosition(String mypagePosition) {
        this.mypagePosition = mypagePosition;
    }

    public String getMypageMainnum() {
        return mypageMainnum;
    }

    public void setMypageMainnum(String mypageMainnum) {
        this.mypageMainnum = mypageMainnum;
    }

    public String getMypageAddress() {
        return mypageAddress;
    }

    public void setMypageAddress(String mypageAddress) {
        this.mypageAddress = mypageAddress;
    }

    public String getMypageBirth() {
        return mypageBirth;
    }

    public void setMypageBirth(String mypageBirth) {
        this.mypageBirth = mypageBirth;
    }

    public String getMypageLog() {
        return mypageLog;
    }

    public void setMypageLog(String mypageLog) {
        this.mypageLog = mypageLog;
    }
}
