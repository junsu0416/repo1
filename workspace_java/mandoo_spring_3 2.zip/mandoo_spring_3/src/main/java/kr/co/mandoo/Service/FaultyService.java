package kr.co.mandoo.Service;

import java.util.List;

public interface FaultyService {
	
	public List faultySelectService();

}
