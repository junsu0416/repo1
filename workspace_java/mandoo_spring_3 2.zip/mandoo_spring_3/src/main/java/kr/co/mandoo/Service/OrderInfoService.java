package kr.co.mandoo.Service;

import java.util.List;

import kr.co.mandoo.dto.OrderInfoDTO;

public interface OrderInfoService{

	List listOrderInfo();
}
