package kr.co.mandoo.Service;

import org.springframework.stereotype.Service;

import kr.co.mandoo.dto.MyPageDTO;

@Service
public interface MyPageService {
	public MyPageDTO myPageRead();
	
	
}
