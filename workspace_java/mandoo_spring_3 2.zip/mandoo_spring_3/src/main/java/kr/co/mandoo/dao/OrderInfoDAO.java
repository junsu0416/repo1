package kr.co.mandoo.dao;

import java.util.List;

public interface OrderInfoDAO {

	List selectorderInfo();

}
