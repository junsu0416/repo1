package kr.co.mandoo.dao;

import java.util.List;

import kr.co.mandoo.dto.FaultyDTO;

public interface FaultyDAO {
	
	public List<FaultyDTO> faultyselect();

}
